<?php
	$var = 3;
	if($var < 0) 
		echo "Es menor que cero";
	if ($var > 0){
		echo "Es mayor que cero";
	}
?>