<?php
	$var = 3;
	if ($var == 1) {
		echo "Es un uno";
	}elseif ($var == 2) {
		echo "Es un dos";
	}elseif ($var == 3) {
		echo "Es un tres";
	}else{
		echo "No es un uno, ni un dos, ni un tres";
	}
?>