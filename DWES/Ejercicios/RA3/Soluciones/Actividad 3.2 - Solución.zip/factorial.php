<?php
    $numero = 5;
	$factorial = 1; 
    if (!is_int($numero) || $numero<0)
		echo "El factorial no está definido para $numero";
	else {
		for ($i = 1; $i <= $numero; $i++){ 
			$factorial = $factorial * $i; 
		} 
		echo "Factorial de $numero  = $factorial"; 
	}
?>