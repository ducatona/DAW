<html>
	<head>
		<meta http-equiv="content-type" content="text/html; charset=UTF-8">
		<title>Fecha en castellano</title>
	</head>
	<body>
	<?php
	//Función que devuelve un texto con la fecha actual en castellano
	function fecha(){
		date_default_timezone_set('Europe/Madrid');
		$numero_mes = date("m");
		$numero_dia_semana = date("N");
		$meses=array("Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre");
		$dias=array("Lunes","Martes","Miércoles","Jueves","Viernes","Sábado","Domingo");
		$mes=$meses[$numero_mes-1];
		$dia_semana=$dias[$numero_dia_semana-1];
		return $dia_semana.", ".date("j")." de ".$mes." de ".date("Y");
	}
	
	//Programa principal
	print "Hoy es: ".fecha();
	?>
	</body>
</html>