<!DOCTYPE html>
<html>
    <head>
        <title>Fusión de arrays</title>
    </head>
    <body>
        <?php
            function cargar($numeroElementos)
            {
                for ($i = 0; $i < $numeroElementos; $i++)
                {
                    $numeros[$i] = rand(0,99);
                }
                return $numeros;
            }

            function mostrar($array)
            {
                foreach ($array as $elemento)
                {
                    echo $elemento . " ";
                }
                echo "<br /><br />";
            }

            function ordenar($array)
            {
                $n = count($array);
                for ($i = 1; $i < $n; $i++)
                {
                    for ($j = 0; $j < ($n - $i); $j++)
                    {
                        if ($array[$j] > $array[$j + 1])
                        {
                            $aux           = $array[$j];
                            $array[$j]     = $array[$j + 1];
                            $array[$j + 1] = $aux;
                        }
                    }
                }
                return $array;
            }

            function mezclar($array1, $array2)
            {
                foreach ($array2 as $valor)
                {
                    $array1[] = $valor;
                }
                return $array1;
            }

            $array1 = cargar(20);
			$array2 = cargar(20);
			mostrar($array1);
			mostrar($array2);
			$array1=ordenar($array1);
			$array2=ordenar($array2);
			mostrar($array1);
			mostrar($array2);
			$array=mezclar($array1,$array2);
			mostrar($array);
			$array=ordenar($array);
			mostrar($array);
        ?>
    </body>
</html>

