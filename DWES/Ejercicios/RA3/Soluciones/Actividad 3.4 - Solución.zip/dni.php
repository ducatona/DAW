<!DOCTYPE html>
<html>
    <head>
        <title>DNI</title>
    </head>
    <body>
        <?php
            $arrayLetras = array("T", "R", "W", "A", "G", "M", "Y", "F", "P", "D", "X", 
							"B", "N", "J", "Z", "S", "Q", "V", "H", "L", "C", "K", "E");
            $dni         = "12345678";
            $resto       = $dni % 23;
            echo "El DNI completo es: $dni".$arrayLetras[$resto];
        ?>
    </body>
</html>
