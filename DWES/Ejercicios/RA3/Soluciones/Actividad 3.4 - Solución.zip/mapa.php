<?php
	$mapa=array("España"=>"Madrid",
				"Portugal"=>"Lisboa",
				"Francia"=>"París",
				"Italia"=>"Roma",
				"Alemania"=>"Berlín",
				"Grecia"=>"Atenas");
				
	print_r($mapa);
	echo $mapa["Italia"];
	if (array_key_exists("Rusia",$mapa)) echo "<br>Rusia está en el mapa.";
	else echo "<br>Rusia no está en el mapa.";
	echo "<br>";
	foreach ($mapa as $pais => $capital)
		echo "<br>$pais => $capital";
	unset ($mapa["Francia"]);
	echo "<br>";
	foreach ($mapa as $pais => $capital)
		echo "<br>$pais => $capital";
	echo "<br>";
	echo "<br>".array_search("Lisboa",$mapa);
	
?>