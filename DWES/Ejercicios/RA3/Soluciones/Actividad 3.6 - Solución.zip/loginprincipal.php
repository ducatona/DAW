<!DOCTYPE html>
<html>
	<head>
		<title>Formulario de login</title>		
		<meta charset = "UTF-8">
	</head>
	<body>			
		<center><h3><p>Bienvenido al sistema</p></h3></center>
	</body>
</html>