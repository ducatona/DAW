<?php
	$suma = 0;
	for($i=10;$i<=100;$i++)
	{
		if($i%2==0)
		$suma+=$i;
	}   
	echo "El resultado de la suma es $suma";
?>