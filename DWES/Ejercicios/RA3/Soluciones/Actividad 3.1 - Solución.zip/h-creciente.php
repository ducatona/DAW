<?php
	for ($i=1;$i<=10;$i++){
		for ($z=1;$z<=$i;$z++)
			echo "$z ";
		echo "<br>";
	}
?>		
	