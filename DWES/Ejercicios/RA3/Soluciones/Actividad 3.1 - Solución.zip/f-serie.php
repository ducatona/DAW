<?php
	for ($i=1,$z=2;$i<=10;$i++){
		echo "$i/$z, ";
		$z=2*$z;
	}
?>
		
	