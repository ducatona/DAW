<?php
	for ($i=10;$i>=1;$i--){
		for ($z=$i;$z>=1;$z--)
			echo "$z ";
		echo "<br>";
	}
?>