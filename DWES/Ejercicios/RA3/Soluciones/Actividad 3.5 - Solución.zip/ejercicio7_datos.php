<!DOCTYPE html>
<html>
    <head>
        <title>Ejercicio 7 - Resultado de la lista de pares de números</title>
    </head>
    <body>
        <?php 
            if (isset($_POST['menor']) && isset($_POST['mayor']))
            {
                echo "LISTA DE PARES DE NÚMEROS DE " . $_POST['menor'] . " Y " . $_POST['mayor'] . ":<br>";
                for ($x = $_POST['menor']; $x <= $_POST['mayor']; $x++)
                {
                    $aux = $_POST['mayor'] - ($x - $_POST['menor']);
                    echo "($x,$aux) ";
                }
            }
        ?>
        <br/><br/><a href='ejercicio7.html'>Volver</a>
    </body>
</html>