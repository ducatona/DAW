<!DOCTYPE html>
<html>
    <head>
        <title>Ejercicio 4 (procesa)</title>
    </head>
    <body>
        <?php
            if (isset($_REQUEST['enviar']))
            {
                echo "El alumno es ".$_REQUEST['nombre']."<br/>";
                echo "El curso elegido es <strong>" . $_REQUEST['curso'] . "</strong>";
            }

        ?>
        <br /><a href='ejercicio2_request.html'>Volver</a>
    </body>
</html>
