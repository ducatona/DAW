<!DOCTYPE html>
<html>
    <head>
        <title>Ejercicio 8 - Resultado de calcular una operación</title>
    </head>
    <body>
        <?php
            if (isset($_POST['primero']) && isset($_POST['segundo']) && isset($_POST['opera']))
            {
                if ($_POST['opera'] == "suma")
                {
                    echo "El resultado de realizar la suma de los números " . $_POST['primero'] . " y " . $_POST['segundo'] . " es " .
                        ($_POST['primero'] + $_POST['segundo']);
                }
                else if ($_POST['opera'] == "resta")
                {
                    echo "El resultado de realizar la resta de los números " . $_POST['primero'] . " y " . $_POST['segundo'] . " es " .
                        ($_POST['primero'] - $_POST['segundo']);
                }
                else if ($_POST['opera'] == "producto")
                {
                    echo "El resultado de realizar el producto de los números " . $_POST['primero'] . " y " . $_POST['segundo'] . " es " .
                        ($_POST['primero'] * $_POST['segundo']);
                }
                else if ($_POST['opera'] == "cociente")
                {
                    if ($_POST['segundo'] == 0)
                    {
                        echo "Imposible realizar una división por CERO.";
                    }
                    else
                    {
                        echo "El resultado de realizar el cociente de los números " . $_POST['primero'] . " y " . $_POST['segundo'] . " es " .
                            ($_POST['primero'] / $_POST['segundo']);
                    }
                }
                else
                {
                    echo "ERROR: Operación incorrecta " . $_POST['opera'];
                }

            }
        ?>
        <br/><br/><a href='ejercicio8.html'>Volver</a> 
    </body>
</html>