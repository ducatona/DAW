<!DOCTYPE html>
<html>
    <head>
        <title>Ejercicio 5 (Resultado comprobar paridad)</title>
    </head>
    <body>
        <?php
            if (isset($_POST['enviar']))
            {
                //comprobamos que ha metido un numero y exista la variable
                if(isset($_POST['numero'])){
                    //comprobarmos si es múltiplo de 2 -par
                    if( ($_POST['numero'] % 2)==0){
                        // construimos la página 
                        echo "<h1>El numero ".$_POST['numero']. " es par</h1><br />";
                    }
                    else{
                        echo "<h1>El numero ".$_POST['numero']. " es impar</h1><br />";
                    }
                }
            }
        ?>
        <br /><a href='ejercicio5.html'>Volver</a>
    </body>
</html>
