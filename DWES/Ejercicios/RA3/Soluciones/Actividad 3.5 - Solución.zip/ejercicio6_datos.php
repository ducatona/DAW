<!DOCTYPE html>
<html>
    <head>
        <title>Ejercicio 6 - Resultado de la construcción de la tabla de multiplicar</title>
    </head>
    <body>
        <?php
            if (isset($_POST['numero']))
            {
                // Comprobamos si existe el parámetro numero pasado desde el formulario
                echo "TABLA DE MULTIPLICAR DEL " . $_POST['numero'] . ":<br/>";
                for ($x = 1; $x <= 10; $x++)
                {
                    $resultado = $x * $_POST['numero'];
                    echo "$x x " . $_POST['numero'] . " = $resultado<br/>";
                }
            }
        ?>
        <br><a href='ejercicio6.html'>Volver</a>
    </body>
</html>