<!DOCTYPE html>
<html>
    <head>
        <title>Ejercicio 3 (procesa)</title>
    </head>
    <body>
        <?php
            if (isset($_POST['enviar']))
            {
                echo "El alumno es ".$_POST['nombre']."<br/>";
                echo "El curso elegido es <strong>" . $_POST['curso'] . "</strong>";
            }

        ?>
        <br /><a href='ejercicio2_get.html'>Volver</a>

    </body>
</html>
