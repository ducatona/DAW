<html>
<head>
    <!-- Especifica la codificación de caracteres y define el título de la página -->
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>Desarrollo Web</title>
</head>
<body>
<?php
// Verifica si el formulario fue enviado correctamente, es decir, si existen valores en 'modulos' y 'nombre'
if (!empty($_POST['modulos']) && !empty($_POST['nombre'])) {
    // Si ambos campos no están vacíos, se almacenan sus valores
    $nombre = $_POST['nombre'];
    $modulos = $_POST['modulos'];
    
    // Se imprime el nombre ingresado
    print "Nombre: " . $nombre . "<br />";
    
    // Se recorre el array de módulos seleccionados y se imprimen
    foreach ($modulos as $modulo) {
        print "Modulo: " . $modulo . "<br />";
    }
} else {
    // Si los campos no están completos, se muestra el formulario para ingresar los datos
    ?>
    Nombre del alumno:
    <!-- El formulario envía los datos a la misma página usando POST -->
    <form name="input" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">

        <!-- Si se ha enviado el formulario pero el campo 'nombre' está vacío, muestra un mensaje de error -->
        <?php
        if (isset($_POST['enviar']) && empty($_POST['nombre']))
            echo "<span style='color:red'> &lt;-- Debe introducir un nombre!!</span>";
        ?><br/>
        
        <!-- Campo de texto para ingresar el nombre del alumno -->
        <input type="text" name="nombre"/>
        
        <p>Módulos que cursa:
            <!-- Si se ha enviado el formulario pero no se seleccionaron módulos, muestra un mensaje de error -->
            <?php
            if (isset($_POST['enviar']) && empty($_POST['modulos']))
                echo "<span style='color:red'> &lt;-- Debe escoger al menos uno!!</span>";
            ?>
        </p>
        
        <!-- Checkbox para seleccionar el módulo "Desarrollo web en entorno servidor" -->
        <input type="checkbox" name="modulos[]" value="DWES"
            <?php
            // Si el formulario fue enviado previamente y este módulo fue seleccionado, el checkbox permanece marcado
            if (isset($_POST['modulos']) && in_array("DWES", $_POST['modulos']))
                echo 'checked="checked"';
            ?>
        />
        Desarrollo web en entorno servidor
        <br/>

        <!-- Checkbox para seleccionar el módulo "Desarrollo web en entorno cliente" -->
        <input type="checkbox" name="modulos[]" value="DWEC"
            <?php
            // Si el formulario fue enviado previamente y este módulo fue seleccionado, el checkbox permanece marcado
            if (isset($_POST['modulos']) && in_array("DWEC", $_POST['modulos']))
                echo 'checked="checked"';
            ?>
        />
        Desarrollo web en entorno cliente<br/>
        <br/>
        
        <!-- Botón para enviar el formulario -->
        <input type="submit" value="Enviar" name="enviar"/>
    </form>
    <?php
}
?>
</body>
</html>
