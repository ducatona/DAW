<html>
<head>
    <!-- Especifica la codificación de caracteres y define el título de la página -->
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>Color Favorito</title>
</head>
<body>
<?php
// Verifica si el formulario fue enviado correctamente, es decir, si existen valores en 'color' y 'usuario'
if (!empty($_POST['color']) && !empty($_POST['usuario'])) {
    // Si ambos campos no están vacíos, se almacenan sus valores
    $usuario = $_POST['usuario'];
    $color = $_POST['color'];
    
    // Se imprime el nombre del usuario y el color seleccionado
    print "Usuario: " . $usuario . "<br />";
    print "Color favorito: " . $color . "<br />";
} else {
    // Si los campos no están completos, se muestra el formulario para ingresar los datos
    ?>
    Nombre del usuario:
    <!-- El formulario envía los datos a la misma página usando POST -->
    <form name="input" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">

        <!-- Si se ha enviado el formulario pero el campo 'usuario' está vacío, muestra un mensaje de error -->
        <?php
        if (isset($_POST['enviar']) && empty($_POST['usuario']))
            echo "<span style='color:red'> &lt;-- Debe introducir un nombre de usuario!!</span>";
        ?><br/>
        
        <!-- Campo de texto para ingresar el nombre del usuario -->
        <input type="text" name="usuario"/>
        
        <p>Selecciona tu color favorito:
            <!-- Si se ha enviado el formulario pero no se seleccionó un color, muestra un mensaje de error -->
            <?php
            if (isset($_POST['enviar']) && empty($_POST['color']))
                echo "<span style='color:red'> &lt;-- Debe seleccionar un color!!</span>";
            ?>
        </p>

        <!-- Botones radiales para seleccionar el color "Rojo" -->
        <input type="radio" name="color" value="Rojo"
            <?php
            // Si el formulario fue enviado previamente y "Rojo" fue seleccionado, el botón permanece marcado
            if (isset($_POST['color']) && $_POST['color'] == "Rojo")
                echo 'checked="checked"';
            ?>
        />
        Rojo
        <br/>

        <!-- Botones radiales para seleccionar el color "Azul" -->
        <input type="radio" name="color" value="Azul"
            <?php
            // Si el formulario fue enviado previamente y "Azul" fue seleccionado, el botón permanece marcado
            if (isset($_POST['color']) && $_POST['color'] == "Azul")
                echo 'checked="checked"';
            ?>
        />
        Azul
        <br/>

        <!-- Botones radiales para seleccionar el color "Verde" -->
        <input type="radio" name="color" value="Verde"
            <?php
            // Si el formulario fue enviado previamente y "Verde" fue seleccionado, el botón permanece marcado
            if (isset($_POST['color']) && $_POST['color'] == "Verde")
                echo 'checked="checked"';
            ?>
        />
        Verde
        <br/>

        <!-- Botones radiales para seleccionar el color "Amarillo" -->
        <input type="radio" name="color" value="Amarillo"
            <?php
            // Si el formulario fue enviado previamente y "Amarillo" fue seleccionado, el botón permanece marcado
            if (isset($_POST['color']) && $_POST['color'] == "Amarillo")
                echo 'checked="checked"';
            ?>
        />
        Amarillo
        <br/>
        
        <!-- Botón para enviar el formulario -->
        <input type="submit" value="Enviar" name="enviar"/>
    </form>
    <?php
}
?>
</body>
</html>
