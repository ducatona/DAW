<html>
<head>
    <!-- Especifica la codificación de caracteres y define el título de la página -->
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>Deportes Favoritos</title>
</head>
<body>
<?php
// Verifica si el formulario fue enviado correctamente, es decir, si existen valores en 'deportes' y 'usuario'
if (!empty($_POST['deportes']) && !empty($_POST['usuario'])) {
    // Si ambos campos no están vacíos, se almacenan sus valores
    $usuario = $_POST['usuario'];
    $deportes = $_POST['deportes'];
    
    // Se imprime el nombre del usuario ingresado
    print "Usuario: " . $usuario . "<br />";
    
    // Se recorre el array de deportes seleccionados y se imprimen
    foreach ($deportes as $deporte) {
        print "Deporte: " . $deporte . "<br />";
    }
} else {
    // Si los campos no están completos, se muestra el formulario para ingresar los datos
    ?>
    Nombre del usuario:
    <!-- El formulario envía los datos a la misma página usando POST -->
    <form name="input" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">

        <!-- Si se ha enviado el formulario pero el campo 'usuario' está vacío, muestra un mensaje de error -->
        <?php
        if (isset($_POST['enviar']) && empty($_POST['usuario']))
            echo "<span style='color:red'> &lt;-- Debe introducir un nombre de usuario!!</span>";
        ?><br/>
        
        <!-- Campo de texto para ingresar el nombre del usuario -->
        <input type="text" name="usuario"/>
        
        <p>Deportes favoritos:
            <!-- Si se ha enviado el formulario pero no se seleccionaron deportes, muestra un mensaje de error -->
            <?php
            if (isset($_POST['enviar']) && empty($_POST['deportes']))
                echo "<span style='color:red'> &lt;-- Debe seleccionar al menos uno!!</span>";
            ?>
        </p>
        
        <!-- Checkbox para seleccionar "Fútbol" como deporte favorito -->
        <input type="checkbox" name="deportes[]" value="Futbol"
            <?php
            // Si el formulario fue enviado previamente y "Fútbol" fue seleccionado, el checkbox permanece marcado
            if (isset($_POST['deportes']) && in_array("Futbol", $_POST['deportes']))
                echo 'checked="checked"';
            ?>
        />
        Fútbol
        <br/>

        <!-- Checkbox para seleccionar "Baloncesto" como deporte favorito -->
        <input type="checkbox" name="deportes[]" value="Baloncesto"
            <?php
            // Si el formulario fue enviado previamente y "Baloncesto" fue seleccionado, el checkbox permanece marcado
            if (isset($_POST['deportes']) && in_array("Baloncesto", $_POST['deportes']))
                echo 'checked="checked"';
            ?>
        />
        Baloncesto
        <br/>

        <!-- Checkbox para seleccionar "Tenis" como deporte favorito -->
        <input type="checkbox" name="deportes[]" value="Tenis"
            <?php
            // Si el formulario fue enviado previamente y "Tenis" fue seleccionado, el checkbox permanece marcado
            if (isset($_POST['deportes']) && in_array("Tenis", $_POST['deportes']))
                echo 'checked="checked"';
            ?>
        />
        Tenis
        <br/>

        <!-- Checkbox para seleccionar "Natación" como deporte favorito -->
        <input type="checkbox" name="deportes[]" value="Natacion"
            <?php
            // Si el formulario fue enviado previamente y "Natación" fue seleccionado, el checkbox permanece marcado
            if (isset($_POST['deportes']) && in_array("Natacion", $_POST['deportes']))
                echo 'checked="checked"';
            ?>
        />
        Natación
        <br/>
        
        <!-- Botón para enviar el formulario -->
        <input type="submit" value="Enviar" name="enviar"/>
    </form>
    <?php
}
?>
</body>
</html>
