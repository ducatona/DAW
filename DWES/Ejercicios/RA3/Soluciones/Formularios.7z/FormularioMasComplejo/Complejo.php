<html>
<head>
    <!-- Especifica la codificación de caracteres y define el título de la página -->
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>Formulario de Usuario Avanzado</title>
</head>
<body>
<?php
// Verifica si el formulario fue enviado correctamente y si los campos principales están llenos
if (!empty($_POST['nombre']) && !empty($_POST['genero']) && !empty($_POST['aficiones']) && !empty($_POST['pais'])) {
    // Recibe y almacena los valores del formulario
    $nombre = $_POST['nombre'];
    $genero = $_POST['genero'];
    $aficiones = $_POST['aficiones'];
    $pais = $_POST['pais'];
    
    // Imprime los datos enviados
    echo "<h2>Información enviada:</h2>";
    echo "Nombre: " . htmlspecialchars($nombre) . "<br />";
    echo "Género: " . htmlspecialchars($genero) . "<br />";
    
    // Recorre y muestra las aficiones seleccionadas
    echo "Aficiones: <br />";
    foreach ($aficiones as $aficion) {
        echo "- " . htmlspecialchars($aficion) . "<br />";
    }
    
    // Muestra el país seleccionado
    echo "País: " . htmlspecialchars($pais) . "<br />";
    
} else {
    // Si los campos obligatorios no están completos, muestra el formulario con mensajes de error si es necesario
    ?>
    <h2>Formulario de Registro</h2>
    <form name="input" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">

        <!-- Campo de texto para el nombre -->
        Nombre del usuario:
        <?php
        // Mensaje de error si el campo 'nombre' está vacío
        if (isset($_POST['enviar']) && empty($_POST['nombre']))
            echo "<span style='color:red'> &lt;-- Debe introducir un nombre!!</span>";
        ?>
        <br/>
        <input type="text" name="nombre" value="<?php if (isset($_POST['nombre'])) echo htmlspecialchars($_POST['nombre']); ?>"/><br/><br/>
        
        <!-- Botones radiales para seleccionar el género -->
        Género:
        <?php
        // Mensaje de error si no se selecciona un género
        if (isset($_POST['enviar']) && empty($_POST['genero']))
            echo "<span style='color:red'> &lt;-- Debe seleccionar un género!!</span>";
        ?>
        <br/>
        <input type="radio" name="genero" value="Masculino" <?php if (isset($_POST['genero']) && $_POST['genero'] == "Masculino") echo 'checked="checked"'; ?>/> Masculino<br/>
        <input type="radio" name="genero" value="Femenino" <?php if (isset($_POST['genero']) && $_POST['genero'] == "Femenino") echo 'checked="checked"'; ?>/> Femenino<br/>
        <input type="radio" name="genero" value="Otro" <?php if (isset($_POST['genero']) && $_POST['genero'] == "Otro") echo 'checked="checked"'; ?>/> Otro<br/><br/>
        
        <!-- Checkboxes para seleccionar aficiones -->
        Aficiones:
        <?php
        // Mensaje de error si no se seleccionan aficiones
        if (isset($_POST['enviar']) && empty($_POST['aficiones']))
            echo "<span style='color:red'> &lt;-- Debe seleccionar al menos una afición!!</span>";
        ?>
        <br/>
        <input type="checkbox" name="aficiones[]" value="Deporte" <?php if (isset($_POST['aficiones']) && in_array("Deporte", $_POST['aficiones'])) echo 'checked="checked"'; ?>/> Deporte<br/>
        <input type="checkbox" name="aficiones[]" value="Lectura" <?php if (isset($_POST['aficiones']) && in_array("Lectura", $_POST['aficiones'])) echo 'checked="checked"'; ?>/> Lectura<br/>
        <input type="checkbox" name="aficiones[]" value="Cine" <?php if (isset($_POST['aficiones']) && in_array("Cine", $_POST['aficiones'])) echo 'checked="checked"'; ?>/> Cine<br/>
        <input type="checkbox" name="aficiones[]" value="Viajar" <?php if (isset($_POST['aficiones']) && in_array("Viajar", $_POST['aficiones'])) echo 'checked="checked"'; ?>/> Viajar<br/><br/>
        
        <!-- Menú desplegable para seleccionar el país de residencia -->
        País de residencia:
        <?php
        // Mensaje de error si no se selecciona un país
        if (isset($_POST['enviar']) && empty($_POST['pais']))
            echo "<span style='color:red'> &lt;-- Debe seleccionar un país!!</span>";
        ?>
        <br/>
        <select name="pais">
            <option value="">-- Seleccione un país --</option>
            <option value="España" <?php if (isset($_POST['pais']) && $_POST['pais'] == "España") echo 'selected="selected"'; ?>>España</option>
            <option value="México" <?php if (isset($_POST['pais']) && $_POST['pais'] == "México") echo 'selected="selected"'; ?>>México</option>
            <option value="Argentina" <?php if (isset($_POST['pais']) && $_POST['pais'] == "Argentina") echo 'selected="selected"'; ?>>Argentina</option>
            <option value="Colombia" <?php if (isset($_POST['pais']) && $_POST['pais'] == "Colombia") echo 'selected="selected"'; ?>>Colombia</option>
            <option value="Chile" <?php if (isset($_POST['pais']) && $_POST['pais'] == "Chile") echo 'selected="selected"'; ?>>Chile</option>
        </select><br/><br/>
        
        <!-- Botón para enviar el formulario -->
        <input type="submit" value="Enviar" name="enviar"/>
    </form>
    <?php
}
?>
</body>
</html>
