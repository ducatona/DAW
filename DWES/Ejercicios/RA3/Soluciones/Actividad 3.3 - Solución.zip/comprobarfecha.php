<!DOCTYPE html>
<html>
    <head>
        <title>Comprobar Fecha</title>
    </head>
    <body>
        <?php
            function comprobarFecha($fecha)
            {
                $dia = (int) substr(($fecha), 0, 2);
                $mes = (int) substr(($fecha), 3, 2);
                $año = (int) substr(($fecha), 6, 4);

                return checkdate($mes, $dia, $año);
            }
            
            $fecha = "22-09-2023";
            echo "La fecha $fecha es";
            echo comprobarFecha($fecha) ? " correcta" : " incorrecta";

            $fecha = "30-02-2023";
            echo "<br />La fecha $fecha es";
            echo comprobarFecha($fecha) ? " correcta" : " incorrecta";

        ?>
    </body>
</html>