<!DOCTYPE html> 
<html>
	<head>
		<meta http-equiv="content-type" content="text/html; charset=UTF-8">
		<title>Fecha en castellano</title>
	</head>
	<body>
		<?php
			include 'funciones.php';
			print "Hoy es: ".fecha();
		?>
	</body>
</html>
