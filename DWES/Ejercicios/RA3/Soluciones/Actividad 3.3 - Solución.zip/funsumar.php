<!DOCTYPE html>
<html>
    <head>
        <title>Función suma</title>
    </head>
    <body>
        <?php
            function sumar($a, int $b)
            {
                return $a + $b;
            }

            echo sumar(5,3);
        ?>
    </body>
</html>