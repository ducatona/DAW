<?php
    function factorial ($numero) {
		$factorial = 1; 
		if (!is_integer($numero) || $numero<0)
			return -1;
		else {
			for ($i = 1; $i <= $numero; $i++){ 
				$factorial = $factorial * $i; 
			} 
			return $factorial; 
		}	
	}
		
	$numero = -3;
	echo "<br>Factorial de $numero  = ".factorial($numero); 
	$numero = "hola";
	echo "<br>Factorial de $numero  = ".factorial($numero); 
	$numero = 0;
	echo "<br>Factorial de $numero  = ".factorial($numero); 
	$numero = 5;
	echo "<br>Factorial de $numero  = ".factorial($numero); 
	$numero = 20;
	echo "<br>Factorial de $numero  = ".factorial($numero); 
?>