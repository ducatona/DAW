<?php
	function is_primo ($n){
		if ($n>1){
			$primo=true;
			for ($i=2;$i<$n;$i++)
				if ($n%$i==0){
					$primo=false;
					break;
				}
		}
		else 
			$primo=false;
		return $primo;
	}
		
	function is_capicua ($i){
		if ($i>99 && $i<1000) {
			$centena=(int)($i/100);
			$unidad= $i%10;
			if ($centena==$unidad)
				$capicua=true;
			else 
				$capicua=false;
			return $capicua;
		}
		else
			return false;
	}
	
	function redondear ($n){
		if (!is_float($n))
			return false;
		else {
			$decimal=(int)($n*10)%10;
			if ($decimal>=5)
				$n=(int)$n+1;
			else 
				$n=(int)$n;
			return $n;
		}
	}
	
	function truncar ($n){
		if (!is_numeric($n))
			return false;
		else {
			$n=(int)$n;
			return $n;
		}
	}
	
	function digitos ($n){
		if (!is_numeric($n))
			return false;
		else {
			$digitos=strlen($n);
			if (is_float($n))
				$digitos=$digitos-1;
			return $digitos;
		}
	}
	
	$numero=757.65;
	$truncado=truncar($numero);
	echo "$numero truncado sería: $truncado <br>";
	$redondeado=redondear($numero);
	echo "$numero redondeado sería: $redondeado <br>";
	$capicua=is_capicua($truncado);
	if ($capicua) echo "$truncado es capicúa <br>";
	$primo=is_primo($truncado);
	if ($primo) echo "$truncado es primo <br>";
	$n_digitos=digitos($numero);
	echo "$numero tiene $n_digitos dígitos <br>";
?>	