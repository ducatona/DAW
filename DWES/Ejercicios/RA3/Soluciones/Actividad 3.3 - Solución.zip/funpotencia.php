<?php
    function potencia ($base, $exponente=2) {
		if (!is_integer($base) || !is_integer($exponente) || $exponente<0)
			return false;
		else {
			$resultado = 1;
			for ($i = 1; $i <= $exponente; $i++)
				$resultado = $resultado * $base; 
			return $resultado; 
		}	
	}
		
	$base = 2;
	$exponente = 3;
	$resultado=potencia($base, $exponente);
	if ($resultado)
		echo "<br>Potencia: ($base)^$exponente  = ".$resultado;
	else
		echo "<br>Error en los datos de entrada: ($base)^$exponente";
	$base = 4;
	$exponente = 2;
	$resultado=potencia($base);
	if ($resultado)
		echo "<br>Potencia: ($base)^$exponente  = ".$resultado;
	else
		echo "<br>Error en los datos de entrada: ($base)^$exponente";
	$base = -3;
	$exponente = 0;
	$resultado=potencia($base, $exponente);
	if ($resultado)
		echo "<br>Potencia: ($base)^$exponente  = ".$resultado;
	else
		echo "<br>Error en los datos de entrada: ($base)^$exponente";
	$base = -2;
	$exponente = 3;
	$resultado=potencia($base, $exponente);
	if ($resultado)
		echo "<br>Potencia: ($base)^$exponente  = ".$resultado;
	else
		echo "<br>Error en los datos de entrada: ($base)^$exponente";
	$base = 2;
	$exponente = -1;
	$resultado=potencia($base, $exponente);
	if ($resultado)
		echo "<br>Potencia: ($base)^$exponente  = ".$resultado;
	else
		echo "<br>Error en los datos de entrada: ($base)^$exponente";
	$base = "hola";
	$exponente = 4;
	$resultado=potencia($base, $exponente);
	if ($resultado)
		echo "<br>Potencia: ($base)^$exponente  = ".$resultado;
	else
		echo "<br>Error en los datos de entrada: ($base)^$exponente";
	$base = 2;
	$exponente = "z";
	$resultado=potencia($base, $exponente);
	if ($resultado)
		echo "<br>Potencia: ($base)^$exponente  = ".$resultado;
	else
		echo "<br>Error en los datos de entrada: ($base)^$exponente";
?>