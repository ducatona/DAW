<!DOCTYPE html>
<html>
    <head>
        <title>Función imprimir</title>
    </head>
    <body>
        <?php
            function muestraMensaje($mensaje)
            {
                return "El mensaje pasado como parámetro es: <strong>$mensaje</strong>";
            }
            echo muestraMensaje("Estamos en clase de DWES");
        ?>
    </body>
</html>