

<?php $__env->startSection('title', $post->titulo); ?>

<?php $__env->startSection('content'); ?>

<h1><?php echo e($post->titulo); ?></h1>
<p><?php echo e($post->contenido); ?></p>

<h2>Comentarios</h2>

<ul>
<?php $__currentLoopData = $post->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li>
        <?php echo e($comment->autor); ?> dijo:
        <p><?php echo e($comment->contenido); ?></p>
        <small>Publicado el <?php echo e($comment->created_at->format('d/m/Y H:i')); ?></small>
    </li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>

<h3>Añadir comentario</h3>

<?php if(session('success')): ?>
    <p class="success"><?php echo e(session('success')); ?></p>
<?php endif; ?>

<form action="<?php echo e(route('comments.store', $post)); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <label for="autor">Nombre:</label>
    <input type="text" name="autor" id="autor" required>
    <label for="contenido">Comentario:</label>
    <textarea name="contenido" id="contenido" required></textarea>
    <button type="submit">Añadir un comentario</button>
</form>

<a href="<?php echo e(route('posts.index')); ?>" class="button">Volver al listado</a>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Adrián Peña Carnero\Desktop\blog\resources\views/posts/show.blade.php ENDPATH**/ ?>