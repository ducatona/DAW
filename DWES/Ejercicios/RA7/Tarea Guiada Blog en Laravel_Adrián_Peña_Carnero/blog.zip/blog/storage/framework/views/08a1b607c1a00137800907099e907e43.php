


<?php $__env->startSection('title','Editar Post'); ?>


<?php $__env->startSection('content'); ?>

<h1>Editar Post</h1>

<form action="<?php echo e(route('posts.update',$post)); ?>" method="POST"> <!--Obetenemos el id del post pasandole como parametroa  la ruta-->
<?php echo csrf_field(); ?>
<?php echo method_field('PUT'); ?>
<label for="titulo">Titulo:</label>
<input type="text" name="titulo" id="titulo" value="<?php echo e($post->titulo); ?>" required>
<label for="contenido">Contenido:</label>
<textarea name="contenido" id="contenido" required><?php echo e($post->contenido); ?></textarea>
<button type="submit">Actualizar</button>

</form>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Adrián Peña Carnero\Desktop\blog\resources\views/posts/edit.blade.php ENDPATH**/ ?>