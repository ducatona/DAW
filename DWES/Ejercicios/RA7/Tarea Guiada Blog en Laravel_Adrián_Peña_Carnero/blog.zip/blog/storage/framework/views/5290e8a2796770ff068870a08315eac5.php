

<?php $__env->startSection('title','Listado de Posts'); ?>

<?php $__env->startSection('content'); ?>

<h1>Listado de Posts</h1>
<a href="<?php echo e(route('posts.create')); ?>" class="button">Crear nuevo post</a>
<ul>

<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li>
        <a href="<?php echo e(route('posts.show', $post)); ?>"><?php echo e($post->titulo); ?></a>
        <a href="<?php echo e(route('posts.edit', $post)); ?>">Editar</a>

        <form action="<?php echo e(route('posts.destroy', $post)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button type="submit">Eliminar</button>
        </form>
    </li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</ul>

<div class="pagination">
    <?php echo e($posts->links()); ?>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Adrián Peña Carnero\Desktop\blog\resources\views/posts/index.blade.php ENDPATH**/ ?>