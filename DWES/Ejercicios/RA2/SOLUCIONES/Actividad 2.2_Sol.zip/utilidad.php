<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
		<?php
			$var = "";
			// Se evalúa a true ya que $var está vacia
			if (empty($var)) {
				echo '$var es 0, cadena vacía, o no se encuentra definida en absoluto';
			}
			// Se evalúa como true ya que $var está definida
			if (isset($var))
				echo '$var está definida a pesar que está vacía';
			else
				echo "NO EXISTE LA VARIABLE";
			?>
	</body>
</html>
