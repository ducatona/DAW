<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
			function PruebaSinGlobal(){
				$var++;
				echo "Prueba sin global. \$var: ".$var."<br>";
			}
			function PruebaConGlobal(){
				global $var;
				$var++;
				echo "Prueba con global. \$var: ".$var."<br>";
			}
			function PruebaConGlobals(){
				$GLOBALS["var"]++;
				echo "Prueba con GLOBALS. \$var: ".$GLOBALS["var"]."<br>";
			}
			$var=20; //variable global
			PruebaSinGlobal();
			print "\$var=".$var."<br>";
			PruebaConGlobal();
			print "\$var=".$var."<br>";
			PruebaConGlobals();
			print "\$var=".$var."<br>";
?>
    </body>
</html>
