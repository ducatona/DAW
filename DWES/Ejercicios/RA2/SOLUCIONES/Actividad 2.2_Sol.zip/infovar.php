<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
		<?php

			$a = "Cadena de caracteres";
			echo "Variable \$a = ";
			var_dump ($a);
			echo "<br><br>";
			
			$b = 5;
			$c = true;
			echo "Variables \$b y \$c = ";
			var_dump($b,$c);
			echo "<br><br>";

			$matriz[0] = 3;
			$matriz[1] = "Hola";
			$matriz[2] = 7.28;
			$matriz[3] = true;
			$matriz[4] = "Z";
			// Se obtiene información de la variable
			echo "Variable \$matriz = ";
			var_dump($matriz);
			echo "<br><br>";

			$array = array(1, 2, array("a", "b", "c"));
			echo "Variable \$array = ";
			var_dump($array);

			?>
	</body>
</html>
