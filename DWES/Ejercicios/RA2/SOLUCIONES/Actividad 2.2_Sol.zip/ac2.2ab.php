<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
			$a="Hola ";
			$b="mundo!";
			print($a,$b); // no funciona
			//print $a.$b;	// sí funciona
			//echo"<br>";
			//echo $a.$b;		// sí funciona
			//echo"<br>";
			//$a = 5; $b = ++$a; 
			//print '$a='.$a.' $b='.$b;
			//echo"<br>";
			//$a = 5; $b = $a++; 
			//print '$a='.$a.' $b='.$b;
		?>
    </body>
</html>
