<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
			echo "\$_SERVER['PHP_SELF']=".$_SERVER['PHP_SELF']."<br>";
			echo "\$_SERVER['SERVER_ADDR']=".$_SERVER['SERVER_ADDR']."<br>";
			echo "\$_SERVER['SERVER_NAME']=".$_SERVER['SERVER_NAME']."<br>";
			echo "\$_SERVER['DOCUMENT_ROOT']=".$_SERVER['DOCUMENT_ROOT']."<br>";
			echo "\$_SERVER['REMOTE_ADDR']=".$_SERVER['REMOTE_ADDR']."<br>";
?>
    </body>
</html>
