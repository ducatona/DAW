<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
		<?php
			$var1=13; $var2=4;
			$suma = $var1+$var2;
			$resta = $var1-$var2;
			$multiplicacion = $var1*$var2;
			$division = $var1/$var2;
			$resto = $var1%$var2;
			echo "La suma de ".$var1." + ".$var2." es: ".$suma."<br><br>";
			print "La resta de ".$var1." - ".$var2." es: ".$resta;
			printf ("<p>La multiplicación de %d * %d es: %d </p>", $var1, $var2, $multiplicacion);
			printf ("<p>La división de %d / %d es: %0.2f </p>", $var1, $var2, $division);
			echo "El resto de la división de ".$var1." / ".$var2." es: ".$resto."<br>";
			print "<p>El incremento de ".$var1." es: ";
			$incremento = ++$var1;
			print "$incremento</p>";
			print "<p>El decremento de ".$var2." es: ";
			$decremento = --$var2;
			print "$decremento</p>";		
			?>
	</body>
</html>
