<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
		<?php
			define ("PI",3.1416);
			$radio=7;
			$area = PI*$radio*$radio;
			$perimetro = 2*PI*$radio;
			$volumen = (4/3)*PI*$radio*$radio*$radio;
			print "<p>Para un radio = ".$radio."</p>";
			print "<p>El área de la circunferencia es: ".$area."</p>";
			print "<p>El perímetro del círculo es: ".$perimetro."</p>";
			print "<p>El volumen de la esfera es: ".$volumen."</p>";			
			?>
	</body>
</html>
