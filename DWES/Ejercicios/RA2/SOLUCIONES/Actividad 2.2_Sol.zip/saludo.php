<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
			echo "Pablo Escudero";
			date_default_timezone_set('Europe/Madrid');
			$fecha=date("d-F-Y");
			echo "<br> Fecha de conexión: ".$fecha;
			$hora=date("H:i:s");
			echo "<br> Hora de conexión: ".$hora;
        ?>
    </body>
</html>
