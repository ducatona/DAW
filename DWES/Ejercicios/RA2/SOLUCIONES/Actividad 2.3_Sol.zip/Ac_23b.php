<!DOCTYPE html>
<html>
    <head>
	    <title>
		    Apartado b: Mostrar texto en un navegador
	    </title>
    </head>
    <body>
        <?php
            echo "Este es el resultado correcto del primer ejercicio";
        ?>
    </body>
</html>