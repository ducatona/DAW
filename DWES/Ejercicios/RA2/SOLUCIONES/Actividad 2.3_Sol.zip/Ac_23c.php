<!DOCTYPE html>
<html>
    <head>
        <title>
         Apartado c: Uso de variables y comentarios
        </title>
    </head>
    <body>
        <?php
            echo "Segundo ejercicio: visualizacion del contenido de variables <br/>";
            // Esta variable almacenara el nombre del alumno
            $nombre = "Pablo";
            // Esta variable almacenara la edad del alumno
            $edad = "36";
            echo "Mi nombre es: $nombre y mi edad es $edad.<br/>";  
        ?>
    </body>
</html>