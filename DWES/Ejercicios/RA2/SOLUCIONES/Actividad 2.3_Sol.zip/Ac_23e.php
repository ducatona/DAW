<!DOCTYPE html>
<html>
    <head>
	    <title>Apartado e</title>
    </head>
    <body>
	    <h2>Realiza un programa que calcule la media de tres números. </h2>
	    <?php
	        $var1=5;
	        $var2=10;
	        $var3=12;
	        $var_resul=($var1+$var2+$var3)/3;
	        print("El resultado es $var_resul");
	        print "<br> El resultado es $var_resul ";
	    ?>	
    </body>
</html>